import React from "react";

const Images=(props)=> {
    return <img src={props.imgsrc} alt="myPic" className='card__img' />;

};

export default Images;